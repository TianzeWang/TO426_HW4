package com.example.hw5;

public class Bird {
    public String birdName;
    public int ZipCode;
    public String personName;

    public Bird() {
    }


    public Bird(String birdName, int zipCode, String personName) {
        this.birdName = birdName;
        this.ZipCode = zipCode;
        this.personName = personName;
    }



}
